// you can write js here

console.log('exo-5');

let input = 'La pole dance est le meilleur sport au monde';
let vowels = ['a', 'e', 'i', 'o', 'u', 'y'];
let resultArray = [];

/*for (let property of input) {
    console.log(property);
    push(input.indexOf(vowels), resultArray);
}
*/
input.forEach(lettres => {
    console.log(lettres);
});